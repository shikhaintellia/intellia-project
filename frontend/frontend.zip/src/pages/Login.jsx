import React, { useState } from "react";
import "../styles/login.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
const Login = () => {
	const navigate = useNavigate();
	const [userData, setUserData] = useState({
		email: "",
		password: "",
	});
	const loginHandler = async () => {
		const res = await axios.post("/api/admin/signin",userData);
		navigate("/admin")
		console.log(res);
	};
	return (
		<div className="login">
			<div className="outer-div">
				<div className="inner-div">
					<labal className="login-label">Email</labal>
					<input
						onChange={(e) =>
							setUserData({ ...userData, email: e.target.value })
						}
						value={userData.email}
						className="login-input"
						placeholder="Email..."
						type="text"
					/>
				</div>
				<div className="inner-div">
					<labal className="login-label">Password</labal>
					<input
						value={userData.password}
						onChange={(e) =>
							setUserData({ ...userData, password: e.target.value })
						}
						className="login-input"
						placeholder="Password..."
						type="text"
					/>
				</div>

				<div className="inner-div">
					<button onClick={loginHandler}> Login</button>
				</div>
			</div>
		</div>
	);
};

export default Login;
