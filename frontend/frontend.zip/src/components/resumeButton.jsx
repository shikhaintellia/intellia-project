import React, { useState } from "react";
import "../styles/button.css";

const ResumeButton = () => {
	return <button className="profile-bt">Resume</button>;
};

export default ResumeButton;
