import React, { useRef, useState } from "react";
import "../styles/resumeButton.css";
import PdfViewer from "./pdfViewer";

const ResumePopup = ({ url, setIsOpen }) => {
	const bgRef = useRef();
	// const closepop = () => {
	// 	setIsOpen((prev) => !prev);
	// };
	const closePopupWhileClickOnBg = (e) => {
		if (bgRef.current === e.target) setIsOpen((prev) => !prev);
	};
	const [isPdfOpen, setIsPdfOpen] = useState(false);
	const isOpenHandler = () => {
		if (isPdfOpen) setIsOpen((prev) => !prev);
		setIsPdfOpen((prev) => !prev);
	};

 
	return (
		<div
			onClick={closePopupWhileClickOnBg}
			ref={bgRef}
			className="resume-bg"
		>
			<div className="center-div">
				<a href={url} target="blank" download="resume-file.pdf">
					<button>Download PDF</button>
				</a>
				{/* <button onClick={() => handleDownload(url)}>Download</button> */}
				<button onClick={isOpenHandler}>
					{!isPdfOpen ? "View" : "Close"}
				</button>

				{isPdfOpen && <PdfViewer pdfUrl={url} />}
			</div>
		</div>
	);
};

export default ResumePopup;
